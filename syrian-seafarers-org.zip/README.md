
# Syrian Seafarers Representation Project

This is the official GitHub Pages site for the Syrian Seafarers Representation, led by Second Officer Mhmad Mostafa Mansour (MNI).

The website provides:
- Project description
- Official contact details
- Media and document updates
